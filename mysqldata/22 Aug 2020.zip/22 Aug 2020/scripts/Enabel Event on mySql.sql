 show processlist; -- First check whether event is on or not

set Global event_scheduler = on; -- sets event on