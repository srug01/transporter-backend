

 update transporter.suborder set cutofftime = now();
